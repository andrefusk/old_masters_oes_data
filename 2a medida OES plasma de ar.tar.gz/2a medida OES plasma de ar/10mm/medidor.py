'''
programa que recebe input de uma pasta de arquivos e faz medidas
de todos os espectros na respectiva pasta
feito:
receber os pontos
extrair tempo de exposição
modulo para subtração de linha base (feito)
fazer um grafico para cada espectro
afazer:

'''


# modulo para extrair os nomes dos arquivos na pasta
from os import listdir
directory = '.'
fnames = list(fname for fname in listdir(directory) if fname.endswith('.txt'))

# importar do modulo de estatistica media e desvio padrao
from statistics import mean, stdev
from numpy import log

# inicializar o arquivo de resultados
res = open("linhas_medidas.txt","w")

# comprimentos de onda de medidas de bandas intensas que não necessitam subtração de linha base
compondaoh1 = 285.024
compondaoh2 = 307.887
compondaoh3 = 310.634
compondan2exc = 337.219
compondano = 249.017
compondan2cat = 390.97

# comprimentos p temperatura vibracional
compn2sps380 = 379.935
compn2sps370 = 370.742
compn2spsbasei = 360.174
compn2spsbasef = 381.774

# comprimentos p ne
compn2catbase = 392.81


# comp de onda do pico, e comprimentos para subtração de linha base de linhas menores
compondaopico = 777.333
compondaoinicio = 775.59
compondaofinal = 778.639

compondahpico = 656.84
compondahinicio = 654.592
compondahfinal = 658.637

fimespectro = 1087.943

# definir umas listas para conter os valores medidos, separados por ponta ou rente
ohponta1 = []
ohrente1 = []

ohponta2 = []
ohrente2 = []

ohponta3 = []
ohrente3 = []

n2excponta = []
n2excrente = []

oponta = []
orente = []

hponta = []
hrente = []

noponta = []
norente = []

n2catponta = []
n2catrente = []

tvibponta = []
tvibrente = []

neponta = []
nerente = []

# definir uma lista de nomes de arquivo para por no laudo ordem de leitura
arqsfeitos = []

# loop para o programa trabalhar com todos os filenames
for j in range(len(fnames)):
    # decompor o nome pra ver se é ponta ou rente
    nome = fnames[j].split('_')
    # resetar variáveis que dependem do arquivo do momento
    sublinhabaseo = []
    sublinhabaseh = []
    sublinhabasetv = []
    fimgrafico = False
    isponta = False
    isrente = False
    for k in range(len(nome)):
        if nome[k] == 'ponta':
            isponta = True
        if nome[k] == 'rente':
            isrente = True
    # setar as listas de x e y para o grafico
    x = []
    y = []
    # abrir os arquivos conforme os nomes coletados
    f = open(str(fnames[j]), "r")
    lines = f.readlines()
    # passar linha por linha construindo as listas x e y e tirando as informações relevantes p medida
    for i in range(len(lines)):
        # primeiro tirar a exposição da 7a linha para que o programa normalize as intensidades
        if i == 6:
            try:
                line = lines[i].split(':')
                exposicao = float(line[1].replace(',','.'))
            except ValueError:
                pass
            except IndexError:
                pass
        # fazer o split da linha para separar o x do y
        line = lines[i].split()
        # script para extrair os pares x e y do espectro, o que não funciona ele descarta,
        # tipo as linhas iniciais de texto
        try:
            x1 = line[0]
            x1 = float(x1.replace(',', '.'))
            x.append(x1)
            y1 = line[1]
            y1 = float(y1.replace(',', '.'))
            y1 = y1/exposicao
            y.append(y1)
            # tirar a intensidade de OH
            if x1 == compondaoh1:
                if isponta == True:
                    ohponta1.append(y1)
                if isrente == True:
                    ohrente1.append(y1)
            if x1 == compondaoh2:
                if isponta == True:
                    ohponta2.append(y1)
                if isrente == True:
                    ohrente2.append(y1)
            if x1 == compondaoh3:
                if isponta == True:
                    ohponta3.append(y1)
                if isrente == True:
                    ohrente3.append(y1)
            # intensidade N2*
            if x1 == compondan2exc:
                if isponta == True:
                    n2excponta.append(y1)
                if isrente == True:
                    n2excrente.append(y1)
          #NO
            if x1 == compondano:
                if isponta == True:
                    noponta.append(y1)
                if isrente == True:
                    norente.append(y1)
            # intensidade O
            if x1 == compondaoinicio:
                sublinhabaseo.append(y1)
            if x1 == compondaopico:
                sublinhabaseo.append(y1)
            if x1 == compondaofinal:
                sublinhabaseo.append(y1)
                linhabaseo = (sublinhabaseo[0]+sublinhabaseo[2])/2
                intO = sublinhabaseo[1]-linhabaseo
                if isponta == True:
                    oponta.append(intO)
                if isrente == True:
                    orente.append(intO)
            # intensidade H
            if x1 == compn2spsbasei:
                sublinhabaseh.append(y1)
            if x1 == compondahpico:
                sublinhabaseh.append(y1)
            if x1 == compondahfinal:
                sublinhabaseh.append(y1)
                linhabaseh = (sublinhabaseh[0]+sublinhabaseh[2])/2
                inth = sublinhabaseh[1]-linhabaseh
                if isponta == True:
                    hponta.append(inth)
                if isrente == True:
                    hrente.append(inth)
            # temp vib
            if x1 == compn2spsbasei:
                sublinhabasetv.append(y1)
            if x1 == compn2sps370:
                sublinhabasetv.append(y1)
            if x1 == compn2sps380:
                sublinhabasetv.append(y1)
            if x1 == compn2spsbasef:
                sublinhabasetv.append(y1)
            if x1 == compondan2cat:
                if isponta == True:
                    n2catponta.append(y1)
                if isrente == True:
                    n2catrente.append(y1)
                sublinhabasetv.append(y1)
# sublinhabasev+ [basei, 370, 380, basef, 390, basen2cat]
            if x1 == compn2catbase:
                sublinhabasetv.append(y1)
                linhabasetv370 = (sublinhabasetv[0]*(compn2spsbasef-compn2sps370)+sublinhabasetv[3]*(compn2sps370-compn2spsbasei))/(compn2spsbasef-compn2spsbasei)
                inttv370 = sublinhabasetv[1]-linhabasetv370
                linhabasetv380 = (sublinhabasetv[0]*(compn2spsbasef-compn2sps380)+sublinhabasetv[3]*(compn2sps380-compn2spsbasei))/(compn2spsbasef-compn2spsbasei)
                inttv380 = sublinhabasetv[2]-linhabasetv380
                linhabasetv390 = (sublinhabasetv[3]*(compn2catbase-compondan2cat)+sublinhabasetv[5]*(compondan2cat-compn2spsbasef))/(compn2catbase-compn2spsbasef)
                inttv390 = sublinhabasetv[4]-linhabasetv380
### cálculo da temp vib
                tvib1 = inttv370/inttv380/1.126
                tvib3 = log(tvib1)
                tvib2 = -0.465/tvib3*1.16*10000
### cálculo de ne
                ne1 = inttv390/inttv380
                ne2 = ne1 - 0.0108
                ne3 = ne2/1.048
                if isponta == True:
                    tvibponta.append(tvib2)
                    neponta.append(ne3)
                if isrente == True:
                    tvibrente.append(tvib2)
                    nerente.append(ne3)
            if x1 == fimespectro:
                fimgrafico = True

        except ValueError:
            pass
        except IndexError:
            pass
        if fimgrafico == True:
            arqsfeitos.append(fnames[j])
            grphfilen = fnames[j]+"graf.svg"
            import matplotlib.pyplot as plt
            plt.plot(x, y, color="blue", marker="^", linewidth="0.1", markersize="0", label="C. de onda /nm")
            plt.legend(loc="best", fontsize=8)

            plt.xlabel("C. de onda", fontsize=8)
            plt.ylabel("u.a. normalizada", fontsize=8)

            plt.xticks(fontsize=8)
            plt.yticks(fontsize=8)
            plt.axis([200, 1100, -100, 5000])

            plt.title("Gráfico "+fnames[j], fontsize=12)
            plt.savefig(grphfilen,bbox_inches='tight')
            plt.close()

# primeiro anota a ordem de leitura dos arquivos
res.write('Medidas para os arquivos na ordem:\n'+str(arqsfeitos)+'\n\n')
# OH ponta e rente com media e desv pad
res.write('Lista de intensidade OH medido no comprimento de onda ' + str(compondaoh1) + ':' + '\n\n')
res.write('Ponta: '+str(ohponta1)+'\n\nMédia ='+str(mean(ohponta1)).replace('.', ',')+';'+str(stdev(ohponta1)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(ohrente1)+'\n\nMédia ='+str(mean(ohrente1)).replace('.', ',')+';'+str(stdev(ohrente1)).replace('.', ',')+'\n\n')

res.write('Lista de intensidade OH medido no comprimento de onda ' + str(compondaoh2) + ':' + '\n\n')
res.write('Ponta: '+str(ohponta2)+'\n\nMédia ='+str(mean(ohponta2)).replace('.', ',')+';'+str(stdev(ohponta2)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(ohrente2)+'\n\nMédia ='+str(mean(ohrente2)).replace('.', ',')+';'+str(stdev(ohrente2)).replace('.', ',')+'\n\n')

res.write('Lista de intensidade OH medido no comprimento de onda ' + str(compondaoh3) + ':' + '\n\n')
res.write('Ponta: '+str(ohponta3)+'\n\nMédia ='+str(mean(ohponta3)).replace('.', ',')+';'+str(stdev(ohponta3)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(ohrente3)+'\n\nMédia ='+str(mean(ohrente3)).replace('.', ',')+';'+str(stdev(ohrente3)).replace('.', ',')+'\n\n')

res.write('Razão dos 2 comprimentos de OH' + ':' + '\n\n')
res.write('Ponta: '+'\n\nMédia ='+str(mean(ohponta2)/mean(ohponta1)).replace('.', ',')+'\n\n')
res.write('Rente: '+'\n\nMédia ='+str(mean(ohrente2)/mean(ohrente1)).replace('.', ',')+'\n\n')
res.write('Ponta: '+'\n\nMédia ='+str(mean(ohponta3)/mean(ohponta1)).replace('.', ',')+'\n\n')
res.write('Rente: '+'\n\nMédia ='+str(mean(ohrente3)/mean(ohrente1)).replace('.', ',')+'\n\n')
# N2* ponta e rente com media e desv pad
res.write('Lista de intensidade N2* medido no comprimento de onda ' + str(compondan2exc) + ':' + '\n\n')
res.write('Ponta: '+str(n2excponta)+'\n\nMédia ='+str(mean(n2excponta)).replace('.', ',')+';'+str(stdev(n2excponta)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(n2excrente)+'\n\nMédia ='+str(mean(n2excrente)).replace('.', ',')+';'+str(stdev(n2excrente)).replace('.', ',')+'\n\n')
# N2+ ponta com media e desv pad
res.write('Lista de intensidade N2+ medido no comprimento de onda ' + str(compondan2cat) + ':' + '\n\n')
res.write('Ponta: '+str(n2catponta)+'\n\nMédia ='+str(mean(n2catponta)).replace('.', ',')+';'+str(stdev(n2catponta)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(n2catrente)+'\n\nMédia ='+str(mean(n2catrente)).replace('.', ',')+';'+str(stdev(n2catrente)).replace('.', ',')+'\n\n')

# NO ponta e rente com media e desv pad
res.write('Lista de intensidade NO medido no comprimento de onda ' + str(compondano) + ':' + '\n\n')
res.write('Ponta: '+str(noponta)+'\n\nMédia ='+str(mean(noponta)).replace('.', ',')+';'+str(stdev(noponta)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(norente)+'\n\nMédia ='+str(mean(norente)).replace('.', ',')+';'+str(stdev(norente)).replace('.', ',')+'\n\n')
# O ponta e rente com media e desv pad
res.write('Lista de intensidade O medido no comprimento de onda ' + str(compondaopico) + ':' + '\n\n')
res.write('Ponta: '+str(oponta)+'\n\nMédia ='+str(mean(oponta)).replace('.', ',')+';'+str(stdev(oponta)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(orente)+'\n\nMédia ='+str(mean(orente)).replace('.', ',')+';'+str(stdev(orente)).replace('.', ',')+'\n\n')
# H a mesma coisa
res.write('Lista de intensidade H medido no comprimento de onda ' + str(compondahpico) + ':' + '\n\n')
res.write('Ponta: '+str(hponta)+'\n\nMédia ='+str(mean(hponta)).replace('.', ',')+';'+str(stdev(hponta)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(hrente)+'\n\nMédia ='+str(mean(hrente)).replace('.', ',')+';'+str(stdev(hrente)).replace('.', ',')+'\n\n')
# temp vib a mesma coisa
res.write('Lista de temperatura vibracional medido com N2 SPS '+ ':' + '\n\n')
res.write('Ponta: '+str(tvibponta)+'\n\nMédia ='+str(mean(tvibponta)).replace('.', ',')+';'+str(stdev(tvibponta)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(tvibrente)+'\n\nMédia ='+str(mean(tvibrente)).replace('.', ',')+';'+str(stdev(tvibrente)).replace('.', ',')+'\n\n')

res.write('Lista de ne medido com N2 SPS '+ ':' + '\n\n')
res.write('Ponta: '+str(neponta)+'\n\nMédia ='+str(mean(neponta)).replace('.', ',')+';'+str(stdev(neponta)).replace('.', ',')+'\n\n')
res.write('Rente: '+str(nerente)+'\n\nMédia ='+str(mean(nerente)).replace('.', ',')+';'+str(stdev(nerente)).replace('.', ',')+'\n\n')

#res.write('Ponta: '+str(tvibponta))
#res.write('Rente: '+str(tvibrente))

res.close()



