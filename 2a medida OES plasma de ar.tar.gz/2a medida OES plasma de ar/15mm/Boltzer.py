# Script pra tirar os 4 picos do N2 sps e fazer o plot

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


# modulo para extrair os nomes dos arquivos na pasta
from os import listdir
directory = '.'
fnames = list(fname for fname in listdir(directory) if fname.endswith('.txt'))

# importar do modulo de estatistica media e desvio padrao
from statistics import mean, stdev
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

# inicializar o arquivo de resultados
res = open("BOLTZ.txt","w")

# comprimentos p temperatura vibracional
compn2sps380 = 379.935
compn2sps375 = 374.879
compn2sps370 = 370.742
compn2sps367 = 367.525

fimespectro = 1087.943

#inicializar as listas pros picos
boltzrente380 = []
boltzrente375 = []
boltzrente370 = []
boltzrente367 = []

boltzponta380 = []
boltzponta375 = []
boltzponta370 = []
boltzponta367 = []

slopeponta = []
sloperente = []

r2ponta = []
r2rente = []

# definir uma lista de nomes de arquivo para por no laudo ordem de leitura
arqsfeitos = []

for j in range(len(fnames)):
    # decompor o nome pra ver se é ponta ou rente
    nome = fnames[j].split('_')
    fimgrafico = False
    isponta = False
    isrente = False
    for k in range(len(nome)):
        if nome[k] == 'ponta':
            isponta = True
        if nome[k] == 'rente':
            isrente = True
    # setar as listas de x e y para o grafico do espectro
    xspec = []
    yspec = []
    # setar as listas de x e y pro boltzmann plot
    boltzplotx = [6103,4764,2987,1016]
    boltzploty = []
    # abrir os arquivos conforme os nomes coletados
    f = open(str(fnames[j]), "r")
    lines = f.readlines()
    # passar linha por linha construindo as listas x e y e tirando as informações relevantes p medida
    for i in range(len(lines)):
        # primeiro tirar a exposição da 7a linha para que o programa normalize as intensidades
        if i == 6:
            try:
                line = lines[i].split(':')
                exposicao = float(line[1].replace(',','.'))
            except ValueError:
                pass
            except IndexError:
                pass
        # fazer o split da linha para separar o x do y
        line = lines[i].split()
        # script para extrair os pares x e y do espectro, o que não funciona ele descarta,
        # tipo as linhas iniciais de texto
        try:
            x1 = line[0]
            x1 = float(x1.replace(',', '.'))
            xspec.append(x1)
            y1 = line[1]
            y1 = float(y1.replace(',', '.'))
            y1 = y1/exposicao
            yspec.append(y1)
            #tirando os picos desejados
            if x1 == compn2sps367:
                if isponta == True:
                    boltzponta367.append(y1)
                    y2 = np.log(y1)
                    boltzploty.append(y2)
                if isrente == True:
                    boltzrente367.append(y1)
                    y2 = np.log(y1)
                    boltzploty.append(y2)
            if x1 == compn2sps370:
                if isponta == True:
                    boltzponta370.append(y1)
                    y2 = np.log(y1)
                    boltzploty.append(y2)
                if isrente == True:
                    boltzrente370.append(y1)
                    y2 = np.log(y1)
                    boltzploty.append(y2)
            if x1 == compn2sps375:
                if isponta == True:
                    boltzponta375.append(y1)
                    y2 = np.log(y1)
                    boltzploty.append(y2)
                if isrente == True:
                    boltzrente375.append(y1)
                    y2 = np.log(y1)
                    boltzploty.append(y2)
            if x1 == compn2sps380:
                if isponta == True:
                    boltzponta380.append(y1)
                    y2 = np.log(y1)
                    boltzploty.append(y2)
                if isrente == True:
                    boltzrente380.append(y1)
                    y2 = np.log(y1)
                    boltzploty.append(y2)
            if x1 == fimespectro:
                fimgrafico = True
        except ValueError:
            pass
        except IndexError:
            pass
        if fimgrafico == True:
            arqsfeitos.append(fnames[j])
            grphfilen = fnames[j]+"boltz.svg"
           # plt.plot(xspec, yspec, color="blue", marker="^", linewidth="0.1", markersize="0", label="Intensity")
           # plt.legend(loc="best", fontsize=8)
           # plt.xlabel("G /cm-1", fontsize=8)
           #plt.ylabel("Intensity", fontsize=8)
            x = np.array(boltzplotx)
            y = np.array(boltzploty)
            gradient, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            mn = np.min(x)
            mx = np.max(x)
            x1 = np.linspace(mn, mx, 500)
            y1 = gradient * x1 + intercept
            plt.plot(x, y, 'ob')
            plt.plot(x1, y1, '-r')
            plt.savefig(grphfilen, bbox_inches='tight')
            plt.close()
           # print(x)
           # print(y)
            Tv = -1.438777/gradient
      #      Tv = gradient
           # plt.show()
            if isponta == True:
                slopeponta.append(Tv)
                r2ponta.append(r_value ** 2)
            if isrente == True:
                sloperente.append(Tv)
                r2rente.append(r_value ** 2)
# primeiro anota a ordem de leitura dos arquivos
res.write('Medidas para os arquivos na ordem:\n'+str(arqsfeitos)+'\n\n')

#colocar os slopes
res.write('Lista de slopes do plot de boltzmann ' + ':' + '\n\n')
res.write('Ponta: '+str(slopeponta)+'\n\nMédia ='+str(mean(slopeponta)).replace('.', ',')+';'+str(stdev(slopeponta)).replace('.', ',')+str(r2ponta)+'\n\n')
res.write('Rente: '+str(sloperente)+'\n\nMédia ='+str(mean(sloperente)).replace('.', ',')+';'+str(stdev(sloperente)).replace('.', ',')+str(r2rente)+'\n\n')


