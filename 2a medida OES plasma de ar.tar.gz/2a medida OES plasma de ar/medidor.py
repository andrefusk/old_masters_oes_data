'''
programa que recebe input de um arquivo e faz medidas do espectro
de todos os espectros na respectiva pasta
feito:
receber os pontos
extrair tempo de exposição
afazer:
modulo para subtração de linha base
'''

#modulo para extrair os nomes dos arquivos na pasta
from os import listdir
directory = '.'
fnames = list(fname for fname in listdir(directory) if fname.endswith('.txt'))

#importar do modulo de estatistica media e desvio padrao
from statistics import mean, stdev

#inicializar o arquivo de resultados
res = open("linhas_medidas2.txt","w")

#comprimentos de onda de medidas de bandas intensas que não necessitam subtração de linha base
compondaoh = 310.634
compondan2exc = 337.219

#comp de onda do pico, e comprimentos para subtração de linha base de linhas menores
compondaopico = 777.333
compondaoinicio = 775.59
compondaofinal = 778.639

compondahpico = 655.042
compondahinicio = 656.84
compondahfinal = 658.188

#definir umas listas para conter os valores medidos, separados por ponta ou rente
ohponta = []
ohrente = []

n2excponta = []
n2excrente = []

oponta = []
orente = []

hponta = []
hrente = []

#definir uma lista de nomes de arquivo para por no laudo ordem de leitura
arqsfeitos = []

#loop para o programa trabalhar com todos os filenames
for j in range(len(fnames)):
    #decompor o nome pra ver se é ponta ou rente
    nome = fnames[j].split('_')
    #resetar variáveis que dependem do arquivo do momento
    sublinhabaseo = []
    sublinhabaseh = []
    isponta = False
    isrente = False
    for k in range(len(nome)):
        if nome[k] == 'ponta':
            isponta = True
        if nome[k] == 'rente':
            isrente = True
    #setar as listas de x e y, nem sei pq botei se nao vou fazer grafico mas td bem
    x = []
    y = []
    #abrir os arquivos conforme os nomes coletados
    f = open(str(fnames[j]), "r")
    lines = f.readlines()
    #passar linha por linha construindo as listas x e y e tirando as informações relevantes p medida
    for i in range(len(lines)):
        #primeiro tirar a exposição para que o programa normalize as intensidades
        if i == 6:
            line = lines[i].split(':')
            exposicao = float(line[1].replace(',','.'))
        #fazer o split da linha para separar o x do y
        line = lines[i].split()
        # script para extrair os pares x e y do espectro, o que não funciona ele descarta,
        # tipo as linhas iniciais de texto
        try:
            x1 = line[0]
            x1 = float(x1.replace(',', '.'))
            x.append(x1)
            y1 = line[1]
            y1 = float(y1.replace(',', '.'))
            y1 = y1/exposicao
            y.append(y1)
            #tirar a intensidade de OH
            if x1 == compondaoh:
                if isponta == True:
                    ohponta.append(y1)
                if isrente == True:
                    ohrente.append(y1)
            #intensidade N2*
            if x1 == compondan2exc:
                if isponta == True:
                    n2excponta.append(y1)
                if isrente == True:
                    n2excrente.append(y1)
            #intensidade O
            if x1 == compondaoinicio:
                sublinhabaseo.append(y1)
            if x1 == compondaopico:
                sublinhabaseo.append(y1)
            if x1 == compondaofinal:
                sublinhabaseo.append(y1)
                linhabaseo = (sublinhabaseo[0]+sublinhabaseo[2])/2
                intO = sublinhabaseo[1]-linhabaseo
                if isponta == True:
                    oponta.append(intO)
                if isrente == True:
                    orente.append(intO)
            #intensidade H
            if x1 == compondahinicio:
                sublinhabaseh.append(y1)
            if x1 == compondahpico:
                sublinhabaseh.append(y1)
            if x1 == compondahfinal:
                sublinhabaseh.append(y1)
                linhabaseh = (sublinhabaseh[0]+sublinhabaseh[2])/2
                inth = sublinhabaseh[1]-linhabaseh
                if isponta == True:
                    hponta.append(inth)
                if isrente == True:
                    hrente.append(inth)
        except ValueError:
            pass
        except IndexError:
            pass
    arqsfeitos.append(fnames[j])
# primeiro anota a ordem de leitura dos arquivos
res.write('Medidas para os arquivos na ordem:\n'+str(arqsfeitos)+'\n')
# OH ponta e rente com media e desv pad
res.write('Lista de intensidade OH medido no comprimento de onda ' + str(compondaoh) + ':' + '\n')
#res.write('Ponta: '+str(ohponta)+'\nMédia ='+str(mean(ohponta))+'+-'+str(stdev(ohponta))+'\n')
res.write('Rente: '+str(ohrente)+'\nMédia ='+str(mean(ohrente))+'+-'+str(stdev(ohrente))+'\n')
# N2* ponta e rente com media e desv pad
res.write('Lista de intensidade N2* medido no comprimento de onda ' + str(compondan2exc) + ':' + '\n')
#res.write('Ponta: '+str(n2excponta)+'\nMédia ='+str(mean(n2excponta))+'+-'+str(stdev(n2excponta))+'\n')
res.write('Rente: '+str(n2excrente)+'\nMédia ='+str(mean(n2excrente))+'+-'+str(stdev(n2excrente))+'\n')
# O ponta e rente com media e desv pad
res.write('Lista de intensidade O medido no comprimento de onda ' + str(compondaopico) + ':' + '\n')
#res.write('Ponta: '+str(oponta)+'\nMédia ='+str(mean(oponta))+'+-'+str(stdev(oponta))+'\n')
res.write('Rente: '+str(orente)+'\nMédia ='+str(mean(orente))+'+-'+str(stdev(orente))+'\n')
# H a mesma coisa
res.write('Lista de intensidade H medido no comprimento de onda ' + str(compondahpico) + ':' + '\n')
#res.write('Ponta: '+str(hponta)+'\nMédia ='+str(mean(hponta))+'+-'+str(stdev(hponta))+'\n')
res.write('Rente: '+str(hrente)+'\nMédia ='+str(mean(hrente))+'+-'+str(stdev(hrente))+'\n')

res.close()
'''
import matplotlib.pyplot as plt
#print(x)
#print(y)
plt.plot(x,y, color="blue",marker="^", linewidth="0.1", markersize ="0", label="Wavenumber /cm-1")
plt.legend(loc="best", fontsize=8)

plt.xlabel("Wavenumber", fontsize = 8)
plt.ylabel("Abs", fontsize = 8)

plt.xticks(fontsize = 8)
plt.yticks(fontsize = 8)

plt.title("Gráfico doido", fontsize = 12)
plt.show()
'''
